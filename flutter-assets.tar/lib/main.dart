import 'package:flutter/services.dart' show AssetBundle, FontLoader;
import 'package:material_ui/material_ui.dart';

void main() => runApp(const FontAssetsApp());

class FontAssetsApp extends StatefulWidget {
  const FontAssetsApp({super.key});

  @override
  State<FontAssetsApp> createState() => _FontAssetsAppState();
}

class _FontAssetsAppState extends State<FontAssetsApp> {
  Future<void>? _fontLoad;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // DartPad exposes workspace assets through DefaultAssetBundle.
    _fontLoad ??= _loadFont(DefaultAssetBundle.of(context));
  }

  Future<void> _loadFont(AssetBundle assets) async {
    final font = FontLoader('Lobster');
    font.addFont(assets.load('assets/fonts/Lobster-Regular.ttf'));
    await font.load();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Font Assets',
      home: Scaffold(
        appBar: AppBar(title: const Text('Flutter Font Assets')),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: FutureBuilder<void>(
              future: _fontLoad,
              builder: (context, snapshot) => Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Image(
                    image: AssetImage('assets/flutter_logo.png'),
                    width: 96,
                    height: 96,
                  ),
                  const SizedBox(height: 24),
                  const Text('Default font'),
                  const Text('Hello, DartPad!', style: TextStyle(fontSize: 36)),
                  const SizedBox(height: 24),
                  Text(
                    snapshot.hasError
                        ? 'Could not load font: ${snapshot.error}'
                        : 'Custom font: Lobster',
                  ),
                  const Text(
                    'Hello, DartPad!',
                    style: TextStyle(fontFamily: 'Lobster', fontSize: 36),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
