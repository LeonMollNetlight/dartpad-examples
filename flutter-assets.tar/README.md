# Flutter font assets

This example compares the default font with the bundled Lobster font. It also
loads the Flutter logo from the project's assets. If the custom font loads,
the second line appears in a handwritten style.

The example loads the font with `FontLoader` and `DefaultAssetBundle`. A normal
`fonts:` declaration alone falls back to the default font in the current
DartPad Preview beta and main runtimes.

Lobster is from [Google Fonts](https://github.com/google/fonts/tree/main/ofl/lobster)
and is distributed under the SIL Open Font License in `assets/fonts/OFL.txt`.
