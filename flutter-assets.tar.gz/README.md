# Flutter Assets

A Flutter app that displays the Flutter logo from `assets/flutter_logo.png`.
The PNG is included in the project and declared in `pubspec.yaml`.

## How it works

`Image.asset('assets/flutter_logo.png')` loads the image through the widget's
asset bundle. The path is relative to the project root.

In DartPad Preview, select **New → Flutter Assets** or open
`?sample=flutter-assets`. The PNG appears in the file tree and can be opened in
an image preview tab. Select **Beta channel** or **Main channel** in the footer
and run the app. The logo should appear above its file path.

The editor's image preview and the running app load the file separately. If the
PNG opens in the editor but the app reports a missing asset, check that the
selected DartPad runtime supports loading assets from the workspace. This
requires the asset support added in the Dart 3.15 development cycle.

After changing the image, hot reload refreshes the running app's asset and image
caches on runtimes that support workspace assets.
