// Copyright (c) 2026, the Dart project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import 'package:material_ui/material_ui.dart';

void main() {
  runApp(const AssetsApp());
}

class AssetsApp extends StatelessWidget {
  const AssetsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Assets',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: Scaffold(
        appBar: AppBar(title: const Text('Flutter Assets')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/flutter_logo.png',
                  width: 160,
                  height: 160,
                  fit: BoxFit.contain,
                  semanticLabel: 'Flutter logo',
                ),
                const SizedBox(height: 24),
                const Text('assets/flutter_logo.png'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
