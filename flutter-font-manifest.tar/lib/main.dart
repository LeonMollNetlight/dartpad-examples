import 'package:material_ui/material_ui.dart';

void main() => runApp(const FontManifestExample());

class FontManifestExample extends StatelessWidget {
  const FontManifestExample({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Font Test',
      home: Scaffold(
        appBar: AppBar(title: const Text('Flutter Font Test')),
        body: const Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Default font'),
                Text('Hello, DartPad!', style: TextStyle(fontSize: 36)),
                SizedBox(height: 24),
                Text('Declared font: Lobster'),
                Text(
                  'Hello, DartPad!',
                  style: TextStyle(fontFamily: 'Lobster', fontSize: 36),
                ),
                SizedBox(height: 24),
                Text('Lobster should look handwritten.'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
