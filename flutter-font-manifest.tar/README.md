# Flutter font declaration

The project declares Lobster using the standard `fonts:` section of
`pubspec.yaml` and displays it next to the default font. It does not load the
font manually. If the font is registered, the second line looks handwritten.

Lobster is from [Google Fonts](https://github.com/google/fonts/tree/main/ofl/lobster)
and is distributed under the SIL Open Font License in `assets/fonts/OFL.txt`.
